library(corrplot)
library(skimr)
library(lubridate)

library(tseries)
library(forecast)
library(dplyr)
library(magrittr)
library(openxlsx)
library(janitor)
library(smooth)
library(caret)
library(randomForest)
library(doParallel)

options(scipen = 999)
options(digits = 2)
setwd("C:/Users/ragraw3/Downloads/India Demand Lubes/Model Results/")

str(data_X)

ind_prod_list = read.xlsx(xlsxFile = "C:/Users/ragraw3/Downloads/India Demand Lubes/India Product List.xlsx",sheet = "Product List")
prod_status =ind_prod_list %>% select(Material.Code,Description,Status) %>% mutate(Material.Code =as.character(Material.Code))

str(prod_status)

data_X = prod_status %>% inner_join(data_X,by=c("Material.Code" = "Material"))

data_X

dist_count = data_X %>% group_by(Distributor) %>% summarise(count =n())
top_dist = dist_count %>% filter(count>=1500)

material_count = data_X %>% group_by(Material) %>% summarise(count =n())
top_mat = material_count %>% filter(count>840)

prod_family_count = data_X %>% group_by(Product.Family) %>% summarise(count =n())
top_prod_fam = prod_family_count %>% filter(count>=150)


top_dist_list = top_dist$Distributor
top_mat_list = top_mat$Material
top_prod_fam_list = top_prod_fam$Product.Family

data_X$Distributor2 = ifelse(data_X$Distributor %in% top_dist_list,data_X$Distributor,"Others")
data_X$Material2 = ifelse(data_X$Material %in% top_mat_list,data_X$Material,"Others")
data_X$Product.Family2 = ifelse(data_X$Product.Family %in% top_prod_fam_list,data_X$Product.Family,"Others")

sort(table(data_X$Distributor2),decreasing = TRUE)
sort(table(data_X$Material2),decreasing = TRUE)
sort(table(data_X$Product.Family2),decreasing = TRUE)

lag3_rel_data = data_X %>% inner_join(relevant_summary2[c(1,2)],by = c("Distributor","Material"))

lag3_irrel_data = data_X %>% inner_join(irrelevant_summary[c(1,2)],by = c("Distributor","Material"))

rf_data = lag3_rel_data[c(1,3,5,7,8,36:38,11:35)]

# Partitions

str(rf_data)


rf_data = rf_data %>% mutate(Brand.Architecture = factor(Brand.Architecture),
                             Distributor2 = factor(Distributor2),
                             Distributor_AR = factor(Distributor_AR),
                             Material2 = factor(Material2),
                             Package.Group =factor(Package.Group),
                             Product.Family2 = factor(Product.Family2),
                             Product.Line = factor(Product.Line),
                             Synthetic.Indicator = factor(Synthetic.Indicator))

str(rf_data)

write.csv(rf_data,file = "rf_data.csv",row.names = FALSE)


index <- createDataPartition(rf_data$SIV, p = 0.8, list = FALSE)
train <- rf_data[index, ]
test <- rf_data[-index, ]


## Fitting linear redgression model

model_lag.lm = lm(formula = train$SIV~.,data = train)

summary(model_lag.lm)
lag3_rel_data$lm_pred = predict.lm(model_lag.lm,rf_data[-c(33)])

save.image(file = "Linear_model.RData")


model_lag.lm2 = lm(formula = train$SIV~.,data = train)

summary(model_lag.lm)
lag3_rel_data$lm_pred = predict.lm(model_lag.lm,rf_data[-c(33)])

save.image(file = "Linear_model.RData")



## Random forest model

# Train Control 

#oob <-  trainControl(method = 'oob', allowParallel = T)

# Fitting

cl <- makeCluster(detectCores()-4) # paralellization
registerDoParallel(cl) # paralellization

rf_data2 = rf_data

str(rf_data2)



index_rf <- createDataPartition(rf_data2$SIV, p = 0.8, list = FALSE)
train_rf <- rf_data2[index_rf, ]
test_rf <- rf_data2[-index_rf, ]


str(train_rf)

time_start <- Sys.time()
set.seed(505)

model_lag.rf <- randomForest(x = train_rf[-c(33)],y=train_rf$SIV,ntree = 100,nodesize = 850,mtry = 8,replace = TRUE,importance = TRUE)
save.image("India_FCST_RF.RData")

print(model_lag.rf)
model_lag.rf$rsq


## List the importance of the variables.
impVar <- round(randomForest::importance(model_lag.rf), 2)
var_imp =impVar[order(impVar[,1], decreasing=TRUE),]

full_data_rf = data_X[c(1,3,5,7,8,36:38,11:35)]

full_data_rf = full_data_rf %>% mutate(Brand.Architecture = factor(Brand.Architecture),
                                       Distributor2 = factor(Distributor2),
                                       Distributor_AR = factor(Distributor_AR),
                                       Material2 = factor(Material2),
                                       Package.Group =factor(Package.Group),
                                       Product.Family2 = factor(Product.Family2),
                                       Product.Line = factor(Product.Line),
                                       Synthetic.Indicator = factor(Synthetic.Indicator))

str(full_data_rf)

index_rf2 <- createDataPartition(full_data_rf$SIV, p = 0.8, list = FALSE)
train_rf2 <- full_data_rf[index_rf2, ]
test_rf2 <- full_data_rf[-index_rf2, ]


##Fitting regression model on full data
model_lag.lm2 = lm(formula = train_rf2$SIV~.,data = train_rf2)

summary(model_lag.lm2)
full_data_rf$lm_pred = predict.lm(model_lag.lm2,full_data_rf[-c(33,34)])

save.image(file = "Linear_model.RData")

## Tuning Random Forest
tRF <- tuneRF(x = train_rf[-c(33)], 
              y=train_rf$SIV,
              mtryStart = 5, 
              ntreeTry=101, 
              stepFactor = 1.5, 
              improve = 0.001, 
              trace=TRUE, 
              plot = TRUE,
              doBest = TRUE,
              nodesize = 800, 
              importance=TRUE
)

var_imp2 = tRF$importance

tRF$ntree

## Scoring syntax
rf_data2$pred_rf <- predict(tRF,newdata = rf_data2[-c(33)],type = "response")


## Building rf on complete data
tRF2 <- tuneRF(x = train_rf2[-c(33)], 
              y=train_rf2$SIV,
              mtryStart = 5, 
              ntreeTry=101, 
              stepFactor = 1.5, 
              improve = 0.001, 
              trace=TRUE, 
              plot = TRUE,
              doBest = TRUE,
              nodesize = 800, 
              importance=TRUE
)

var_imp3 = tRF2$importance

tRF2$ntree


### Getting DFA Accuracy

## Scoring syntax
full_data_rf$pred_rf <- predict(tRF2,newdata = full_data_rf[-c(33)],type = "response")

data_X$lm_pred = full_data_rf$lm_pred
data_X$rf_pred = full_data_rf$pred_rf

monthly_dfa_lag3 <- data_X %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         es2_ABS_ERROR = abs(es2_pred - SIV),
         es3_ABS_ERROR = abs(es3_pred - SIV),
         lm_ABS_ERROR = abs(lm_pred - SIV),
         rf_ABS_ERROR = abs(rf_pred - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es2 = (1-(sum(es2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es3 = (1-(sum(es3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_lm = (1-(sum(lm_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_rf = (1-(sum(rf_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)

write.csv(monthly_dfa_lag3,file = "overall_data_accuracy.csv",row.names = FALSE)

### Getting DFA Accuracy for Relevant data

lag3_rel_data$rf_pred = rf_data2$pred_rf

monthly_dfa_lag3_rel <- lag3_rel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         es2_ABS_ERROR = abs(es2_pred - SIV),
         es3_ABS_ERROR = abs(es3_pred - SIV),
         lm_ABS_ERROR = abs(lm_pred - SIV),
         rf_ABS_ERROR = abs(rf_pred - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es2 = (1-(sum(es2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es3 = (1-(sum(es3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_lm = (1-(sum(lm_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_rf = (1-(sum(rf_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


write.csv(monthly_dfa_lag3_rel,file = "rel_data_accuracy.csv",row.names = FALSE)

monthly_dfa_lag3_irrel <- lag3_irrel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         es2_ABS_ERROR = abs(es2_pred - SIV),
         es3_ABS_ERROR = abs(es3_pred - SIV),
         lm_ABS_ERROR = abs(lm_pred - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es2 = (1-(sum(es2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_es3 = (1-(sum(es3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_lm = (1-(sum(lm_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


dfa_list_lag3 = list("lag3_overall" =monthly_dfa_lag3,"lag3_relevant" = monthly_dfa_lag3_rel,"lag3_irrelevant" = monthly_dfa_lag3_irrel)
format(dfa_list_lag3,digits = 2)
write.xlsx(dfa_list_lag3,file = "lag3_dfa_values_latest.xlsx")
