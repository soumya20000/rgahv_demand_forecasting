# Libraries

library(corrplot)
library(readr)
library(skimr)
library(lubridate)

library(tseries)
library(forecast)
library(dplyr)
library(magrittr)
library(openxlsx)
library(janitor)
library(smooth)

library(pastecs)
library(caret)
library(randomForest)
library(doParallel)

options(scipen = 999)
options(digits = 2)
setwd("C:/Users/ragraw3/Downloads/India Demand Lubes")

lag_data =read.xlsx(xlsxFile = "FCST_lags.xlsx",sheet = "lags",detectDates = TRUE)

str(lag_data)
lag_data = lag_data  %>% mutate(Material = as.character(Material))

### Getting Dist-Material codes with zero sales throughout 2019
siv_sum = lag_data %>% group_by(Distributor,Material) %>% summarise(sum_siv = sum(SIV))



zero_siv = siv_sum %>% filter(sum_siv==0)
nonzero_siv = siv_sum %>% filter(sum_siv!=0)

nonzero_siv = nonzero_siv[c(-3)]


zero_data = lag_data %>% inner_join(zero_siv[-c(3)],by = c("Distributor","Material"))



## Getting Data with relevant non_zero values
relevant_summary = lag_data %>% group_by(Distributor,Material) %>% summarise(count =n(),
                                                                                  nonzero_count = length(which(SIV!=0)),
                                                                                  siv_total = sum(SIV),
                                                                                  non_zero_percent = round((nonzero_count/count),digits = 3)*100)


relevant_summary2 = relevant_summary %>% filter(non_zero_percent>25)

irrelevant_summary = relevant_summary %>% filter(non_zero_percent<=25)

relevant_data = lag_data %>% inner_join(relevant_summary2[c(1,2)],by = c("Distributor","Material"))



lag3_data_with_macro = read.xlsx("lag_data_with_macro_info.xlsx",sheet = "lag3_data")

lag3_data_with_macro = lag3_data_with_macro %>% select(-"Month.of.Effective.Date") %>% mutate(Month = excel_numeric_to_date(Month,date_system = "modern"))


lag6_data_with_macro = read.xlsx("lag_data_with_macro_info.xlsx",sheet = "lag6_data")

lag6_data_with_macro = lag6_data_with_macro %>% select(-"Month.of.Effective.Date") %>% mutate(Month = excel_numeric_to_date(Month,date_system = "modern"))



##Modelling 

## Naive model

data_X = as.data.frame(lag3_data_with_macro[c(1:10,14:22,28:42,12)])
data_X2 = as.data.frame(lag6_data_with_macro[c(1:10,14:31,37:51,12)])

str(data_X)

### Combining product Status info in the data as well

ind_prod_list = read.xlsx(xlsxFile = "C:/Users/ragraw3/Downloads/India Demand Lubes/India Product List.xlsx",sheet = "Product List")
prod_status =ind_prod_list %>% select(Material.Code,Description,Status) 

names(prod_status)[1]<-"Material"
str(prod_status)

prod_status2 = prod_status %>% group_by(Material,Description) %>% slice(1) %>% ungroup()

str(prod_status2)
prod_status2 = prod_status2 %>% mutate(Material = as.character(Material))

data_X = data_X %>% inner_join(prod_status2,by=c("Material"))


data_X = data_X %>% mutate(Brand.Architecture = as.character(Brand.Architecture),
                                   Distributor = as.character(Distributor),
                                   Distributor_AR = as.character(Distributor_AR),
                                   Material = as.character(Material),
                                   Package.Group =as.character(Package.Group),
                                   Product.Family = as.character(Product.Family),
                                   Product.Line = as.character(Product.Line),
                                   Synthetic.Indicator = as.character(Synthetic.Indicator))

str(data_X)

dist_count = data_X %>% group_by(Distributor) %>% summarise(count =n())
top_dist = dist_count %>% filter(count>=1400)

material_count = data_X %>% group_by(Material) %>% summarise(count =n())
top_mat = material_count %>% filter(count>840)

prod_family_count = data_X %>% group_by(Product.Family) %>% summarise(count =n())
top_prod_fam = prod_family_count %>% filter(count>=130)

data_X$Distributor2 = ifelse(data_X$Distributor %in% top_dist$Distributor,data_X$Distributor,"Others")
data_X$Material2 = ifelse(data_X$Material %in% top_mat$Material,data_X$Material,"Others")
data_X$Product.Family2 = ifelse(data_X$Product.Family %in% top_prod_fam$Product.Family,data_X$Product.Family,"Others")

sort(table(data_X$Distributor2),decreasing = TRUE)
sort(table(data_X$Material2),decreasing = TRUE)
sort(table(data_X$Product.Family2),decreasing = TRUE)


### Modified lag 6 (data_X2) data as well

data_X2 = data_X2 %>% inner_join(prod_status2,by=c("Material"))

str(data_X2)

data_X2$Distributor2 = ifelse(data_X2$Distributor %in% top_dist$Distributor,data_X2$Distributor,"Others")
data_X2$Material2 = ifelse(data_X2$Material %in% top_mat$Material,data_X2$Material,"Others")
data_X2$Product.Family2 = ifelse(data_X2$Product.Family %in% top_prod_fam$Product.Family,data_X2$Product.Family,"Others")


data_X$sma2_pred = apply(X = data_X[c(11:12)],1,FUN = function(x){
  return(mean(x))
})

data_X$sma3_pred = apply(X = data_X[c(11:13)],1,FUN = function(x){
  return(mean(x))
})

data_X2$sma2_pred = apply(X = data_X2[c(11:12)],1,FUN = function(x){
  return(mean(x))
})

data_X2$sma3_pred = apply(X = data_X2[c(11:13)],1,FUN = function(x){
  return(mean(x))
})

data_X2$sma4_pred = apply(X = data_X2[c(11:14)],1,FUN = function(x){
  return(mean(x))
})

data_X2$sma5_pred = apply(X = data_X2[c(11:15)],1,FUN = function(x){
  return(mean(x))
})

data_X2$sma6_pred = apply(X = data_X2[c(11:16)],1,FUN = function(x){
  return(mean(x))
})


##Exponential Smoothing Predictions

ses_smoothing<-function(y){
  ses_mod = ses(y,initial = "simple",h=5)
  return(ses_mod$mean[2])
}


ses_pred_data = data.frame(fix.empty.names = TRUE)
ses_pred_data2 = data.frame(fix.empty.names = TRUE)

lag_data2 = lag_data[c(2,4,5,13)]


lag_data2 = lag_data2 %>% filter(Month.of.Effective.Date < "2019-08-01")

for(row in 1:nrow(siv_sum)){
  dist = siv_sum[row,"Distributor"]
  prod = siv_sum[row,"Material"]
  print(paste("row",row))
  data2 =  lag_data2 %>%filter(Distributor == dist$Distributor & Material==prod$Material)
  
  print(nrow(data2))
  print(ncol(data2))
  
  ts_data = ts(data = data2[c(4)])
  print(ts_data)
  ses_mod = ses(ts_data,initial = "simple")
  data2 = cbind(data2,as.numeric(ses_mod$fitted))
  ses_pred_data2 = rbind(ses_pred_data2,data2)
  
}


# names(ses_pred_data)[5]<-"ses_pred"
# names(ses_pred_data)[3]<-"Month"
# 
# ses_pred_data = ses_pred_data[-c(4)]

names(ses_pred_data2)[5]<-"ses_pred"
names(ses_pred_data2)[3]<-"Month"

ses_pred_data2 = ses_pred_data2[-c(4)]
write.csv(ses_pred_data2,"ses_pred_7months.csv",row.names=FALSE)

new_data_X = data_X %>% inner_join(ses_pred_data2,by=c("Distributor","Material","Month"))

write.csv(new_data_X,file = "new_data_X_latest.csv",row.names = FALSE)
  

### Getting ES prediction for last 7 months using lag2 to lag6 SIV Values

data_X2$ses_pred = apply(X = data_X2[c(11:16)],1,FUN = function(y){
  ses_mod = ses(y,initial = "simple",h=5,)
  return(ses_mod$mean[2])
})



data_X2$ses_pred_optimal = apply(X = data_X2[c(11:16)],1,FUN = function(y){
  ses_mod = ses(y,initial = "optimal",h=5)
  return(ses_mod$mean[2])
})


write.xlsx(x = data_X2,file = "India_DFA_rawdata_with_predictions.xlsx")
save.image(file = "Latest_data_prep.RData")


### Getting DFA Accuracy

monthly_dfa_lag3 <- new_data_X %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


lag3_rel_data = new_data_X %>% inner_join(relevant_summary2[c(1,2)],by = c("Distributor","Material"))

monthly_dfa_lag3_rel <- lag3_rel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


lag3_irrel_data = new_data_X %>% inner_join(irrelevant_summary[c(1,2)],by = c("Distributor","Material"))

monthly_dfa_lag3_irrel <- lag3_irrel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(EMAPS.Forecast..Ltrs. - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma2_ABS_ERROR = abs(sma2_pred - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma2 = (1-(sum(sma2_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)

setwd("C:/Users/ragraw3/Downloads/India Demand Lubes/Model Results")
dfa_list_lag3 = list("lag3_overall" =monthly_dfa_lag3,"lag3_relevant" = monthly_dfa_lag3_rel,"lag3_irrelevant" = monthly_dfa_lag3_irrel)
format(dfa_list_lag3,digits = 2)

write.xlsx(dfa_list_lag3,file = "lag3_dfa_values_latest2.xlsx")


### Getting DFA Accuracy for lag6 for all the methods

monthly_dfa_lag6 <- data_X2 %>% 
  mutate(EMAPS_ABS_ERROR = abs(`EMAPS.Forecast.(Ltrs)` - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         sma4_ABS_ERROR = abs(sma4_pred - SIV),
         sma5_ABS_ERROR = abs(sma5_pred - SIV),
         sma6_ABS_ERROR = abs(sma6_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma4 = (1-(sum(sma4_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma5 = (1-(sum(sma5_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma6 = (1-(sum(sma6_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)



lag6_rel_data = data_X2 %>% inner_join(relevant_summary2[c(1,2)],by = c("Distributor","Material"))

monthly_dfa_lag6_rel <- lag6_rel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(`EMAPS.Forecast.(Ltrs)` - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         sma4_ABS_ERROR = abs(sma4_pred - SIV),
         sma5_ABS_ERROR = abs(sma5_pred - SIV),
         sma6_ABS_ERROR = abs(sma6_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma4 = (1-(sum(sma4_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma5 = (1-(sum(sma5_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma6 = (1-(sum(sma6_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


lag6_irrel_data = data_X2 %>% inner_join(irrelevant_summary[c(1,2)],by = c("Distributor","Material"))


monthly_dfa_lag6_irrel <- lag6_irrel_data %>% 
  mutate(EMAPS_ABS_ERROR = abs(`EMAPS.Forecast.(Ltrs)` - SIV),
         Naive_ABS_ERROR = abs(lag_2_SIV - SIV),
         sma3_ABS_ERROR = abs(sma3_pred - SIV),
         sma4_ABS_ERROR = abs(sma4_pred - SIV),
         sma5_ABS_ERROR = abs(sma5_pred - SIV),
         sma6_ABS_ERROR = abs(sma6_pred - SIV),
         ses_ABS_ERROR = abs(ses_pred - SIV),
         ses_opt_ABS_ERROR = abs(ses_pred_optimal - SIV)) %>% 
  group_by(Month) %>% 
  summarise(DFA = (1-(sum(EMAPS_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_naive = (1-(sum(Naive_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma3 = (1-(sum(sma3_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma4 = (1-(sum(sma4_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma5 = (1-(sum(sma5_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_sma6 = (1-(sum(sma6_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses = (1-(sum(ses_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100,
            DFA_ses_opt = (1-(sum(ses_opt_ABS_ERROR, na.rm = T)/sum(SIV, na.rm = T))) * 100)


dfa_list_lag6 = list("lag6_overall" =monthly_dfa_lag6,"lag6_relevant" = monthly_dfa_lag6_rel,"lag6_irrelevant" = monthly_dfa_lag6_irrel)
write.xlsx(dfa_list_lag6,file = "lag6_dfa_values_latest2.xlsx")
